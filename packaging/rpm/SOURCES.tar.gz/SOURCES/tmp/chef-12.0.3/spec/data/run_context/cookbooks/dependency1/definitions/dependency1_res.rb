LibraryLoadOrder.record('dependency1-definition')
