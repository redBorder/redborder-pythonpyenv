LibraryLoadOrder.record('test-with-deps-definition')
