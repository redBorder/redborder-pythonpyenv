default[:george] = "washington"
