LibraryLoadOrder.record('test-definition')
