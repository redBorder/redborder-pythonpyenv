# Starting with Chef 12 reloading an LWRP shouldn't reload the file anymore

actions :never_execute

attribute :ever, :kind_of => String
