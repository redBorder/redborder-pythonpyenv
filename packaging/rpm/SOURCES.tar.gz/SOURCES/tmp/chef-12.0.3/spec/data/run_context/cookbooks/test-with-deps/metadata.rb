name "test-with-deps"
depends "dependency1"
depends "dependency2"
