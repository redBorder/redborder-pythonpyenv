require_relative './openldap/version.rb'

class OpenLDAP
end
