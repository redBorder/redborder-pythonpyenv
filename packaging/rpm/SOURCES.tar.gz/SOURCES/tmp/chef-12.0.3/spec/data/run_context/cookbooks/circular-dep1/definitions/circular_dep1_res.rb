LibraryLoadOrder.record('circular-dep1-definition')
