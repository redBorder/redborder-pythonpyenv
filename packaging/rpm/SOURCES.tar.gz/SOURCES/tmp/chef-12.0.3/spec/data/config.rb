#
# Sample Chef Config File
# 

cookbook_path "/etc/chef/cookbook", "/etc/chef/site-cookbook"

