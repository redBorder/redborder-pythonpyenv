LibraryLoadOrder.record('test-with-deps-resource')
