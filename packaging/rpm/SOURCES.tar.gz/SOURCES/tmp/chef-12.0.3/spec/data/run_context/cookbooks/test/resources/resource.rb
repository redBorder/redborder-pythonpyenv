LibraryLoadOrder.record('test-resource')
