action :prepare_eyes do
  "Prepared"
end

action :watch_paint_dry do
  "This isn't very interesting"
end
