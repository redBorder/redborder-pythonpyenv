LibraryLoadOrder.record('test-provider')
