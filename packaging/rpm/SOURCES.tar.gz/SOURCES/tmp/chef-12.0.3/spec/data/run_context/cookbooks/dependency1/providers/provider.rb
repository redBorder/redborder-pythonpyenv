LibraryLoadOrder.record('dependency1-provider')
