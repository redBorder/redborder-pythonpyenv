LibraryLoadOrder.record("test-with-deps")
