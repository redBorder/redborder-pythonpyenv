LibraryLoadOrder.record('no-default-attr-resource')
