class OpenLDAP
  VERSION = '8.9.10'
end
