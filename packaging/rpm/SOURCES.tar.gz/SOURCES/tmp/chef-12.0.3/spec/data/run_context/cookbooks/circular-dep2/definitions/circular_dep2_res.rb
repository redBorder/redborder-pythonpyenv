LibraryLoadOrder.record('circular-dep2-definition')
