LibraryLoadOrder.record('no-default-attr-definition')
