LibraryLoadOrder.record('circular-dep2-provider')
