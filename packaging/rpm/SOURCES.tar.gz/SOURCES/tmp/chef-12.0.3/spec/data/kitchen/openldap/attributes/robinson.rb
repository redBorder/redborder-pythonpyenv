#
# Smokey lives here
#