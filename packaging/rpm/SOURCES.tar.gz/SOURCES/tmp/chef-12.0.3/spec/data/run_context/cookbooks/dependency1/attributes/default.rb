set_unless[:attr_load_order] = []
set[:attr_load_order] << "dependency1::default"
