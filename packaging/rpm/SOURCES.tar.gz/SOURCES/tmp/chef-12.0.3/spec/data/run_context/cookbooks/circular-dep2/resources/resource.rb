LibraryLoadOrder.record('circular-dep2-resource')
