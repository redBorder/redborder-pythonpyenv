# CHEF-5199 regression test.
return nil
