LibraryLoadOrder.record('test-with-circular-deps-resource')
