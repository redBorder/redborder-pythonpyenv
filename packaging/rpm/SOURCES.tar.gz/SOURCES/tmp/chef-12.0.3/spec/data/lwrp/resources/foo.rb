actions :prepare_thumbs, :twiddle_thumbs
default_action :pass_buck

attribute :monkey, :kind_of => String
