attribute :penguin, :kind_of => String, :default => node[:penguin_name]
