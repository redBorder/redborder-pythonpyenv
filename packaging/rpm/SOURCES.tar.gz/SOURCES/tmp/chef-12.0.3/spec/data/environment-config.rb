#
# Sample Chef Config File
#

environment "production"