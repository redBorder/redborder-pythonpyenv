define :openldap_client, :mothra => "a big monster" do
  cat "#{params[:name]}" do
     pretty_kitty true
  end
end
