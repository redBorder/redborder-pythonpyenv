set_unless[:attr_load_order] = []
set[:attr_load_order] << "circular-dep1::default"


