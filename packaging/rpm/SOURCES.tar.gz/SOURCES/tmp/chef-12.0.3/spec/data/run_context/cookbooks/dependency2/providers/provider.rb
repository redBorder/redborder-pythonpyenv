LibraryLoadOrder.record('dependency2-provider')
