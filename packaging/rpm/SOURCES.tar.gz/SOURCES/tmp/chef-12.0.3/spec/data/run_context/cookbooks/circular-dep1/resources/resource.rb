LibraryLoadOrder.record('circular-dep1-resource')
