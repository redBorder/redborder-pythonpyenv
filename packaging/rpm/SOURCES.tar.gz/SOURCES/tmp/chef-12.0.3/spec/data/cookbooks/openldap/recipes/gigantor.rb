cat "blanket" do
  pretty_kitty false
end
