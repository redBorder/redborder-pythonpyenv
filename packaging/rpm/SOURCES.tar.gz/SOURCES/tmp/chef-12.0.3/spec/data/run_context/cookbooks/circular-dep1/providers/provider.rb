LibraryLoadOrder.record('circular-dep1-provider')
