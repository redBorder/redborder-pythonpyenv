LibraryLoadOrder.record('dependency2-definition')
