# ## INCOMPLETE METADATA ##
# This cookbook is invalid b/c it does not set the `name' of the cookbook.

# Commented out for illustrative purposes
# name             'incomplete-metadata'

maintainer       ''
maintainer_email ''
license          ''
description      'Installs/Configures incomplete-metadata'
long_description 'Installs/Configures incomplete-metadata'
version          '0.1.0'

