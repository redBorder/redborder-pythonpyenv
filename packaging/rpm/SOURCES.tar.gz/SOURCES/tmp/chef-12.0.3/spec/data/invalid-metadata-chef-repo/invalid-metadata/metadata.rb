raise "THIS METADATA HAS A BUG"

name             'invalid-metadata'
maintainer       ''
maintainer_email ''
license          ''
description      'Installs/Configures invalid-metadata'
long_description 'Installs/Configures invalid-metadata'
version          '0.1.0'

