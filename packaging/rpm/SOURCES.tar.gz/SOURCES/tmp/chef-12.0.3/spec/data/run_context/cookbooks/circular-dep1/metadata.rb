name "circular-dep1"
depends "circular-dep2"
