LibraryLoadOrder.record('no-default-attr-provider')
