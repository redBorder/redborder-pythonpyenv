
cat "einstein" do
  pretty_kitty true
end

