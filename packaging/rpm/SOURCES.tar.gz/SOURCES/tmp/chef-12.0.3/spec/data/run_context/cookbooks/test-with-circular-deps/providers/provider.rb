LibraryLoadOrder.record('test-with-circular-deps-provider')
