LibraryLoadOrder.record('dependency1-resource')
