LibraryLoadOrder.record('test-with-deps-provider')
