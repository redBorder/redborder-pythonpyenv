LibraryLoadOrder.record('dependency2-resource')
