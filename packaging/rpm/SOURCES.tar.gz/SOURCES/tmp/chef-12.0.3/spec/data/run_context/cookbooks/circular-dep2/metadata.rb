name "circular-dep2"
depends "circular-dep1"
