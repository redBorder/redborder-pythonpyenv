#one_of_each default attributes
