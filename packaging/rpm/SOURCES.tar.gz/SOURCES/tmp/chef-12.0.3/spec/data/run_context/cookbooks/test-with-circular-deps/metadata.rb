name "test-with-circular-deps"
depends "circular-dep1"
