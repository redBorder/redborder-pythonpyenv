LibraryLoadOrder.record("dependency1")

